""" Module for Value Objects
"""


import uuid

PatientId = uuid.UUID
UserId = uuid.UUID
